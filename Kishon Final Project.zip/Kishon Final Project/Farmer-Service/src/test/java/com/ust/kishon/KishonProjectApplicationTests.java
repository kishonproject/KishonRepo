package com.ust.kishon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KishonProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
